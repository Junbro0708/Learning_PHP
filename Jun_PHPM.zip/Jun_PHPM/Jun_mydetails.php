<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
  <?php
    //setting values
    $fName = "Jun Hyeong";
    $lName = "Park";

    //displaying values to html
    echo "<h1>First Name: $fName</h1>";
    echo "<h1>Last Name: $lName</h1>";
    echo "<img src='https://upload.wikimedia.org/wikipedia/commons/thumb/0/09/Flag_of_South_Korea.svg/510px-Flag_of_South_Korea.svg.png'>";
  ?>
</body>
</html>